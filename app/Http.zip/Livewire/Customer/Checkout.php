<?php

namespace App\Livewire\Customer;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderItemCustomization;
use App\Models\PaymentMethod;
use Livewire\Component;
use Illuminate\Support\Facades\DB;

class Checkout extends Component
{
    public string $customer_name    = '';
    public string $customer_phone   = '';
    public string $customer_address = '';
    public string $delivery_type    = 'delivery';
    public        $payment_method_id = '';
    public string $notes            = '';
    public        $latitude         = null;
    public        $longitude        = null;

    // Facturación
    public bool   $wants_invoice = false;
    public string $document_type = 'ci';
    public string $document      = '';
    public string $company_name  = '';

    const COMPANY_WHATSAPP = '595986150627';

    public function mount(): void
    {
        if (!auth()->check()) {
            $this->redirect(route('login'));
            return;
        }

        if (auth()->user()->cartItems()->count() === 0) {
            $this->redirect(route('cart'));
            return;
        }

        $user = auth()->user();
        $this->customer_name    = $user->name ?? '';
        $this->customer_phone   = $user->phone ?? '';
        $this->customer_address = $user->address ?? '';

        // Precargar datos de facturación si ya los tiene
        if ($user->document) {
            $this->wants_invoice = true;
            $this->document_type = $user->document_type ?? 'ci';
            $this->document      = $user->document ?? '';
            $this->company_name  = $user->company_name ?? '';
        }
    }

    protected function rules(): array
    {
        return [
            'customer_name'     => 'required|string|max:255',
            'customer_phone'    => 'required|string',
            'customer_address'  => $this->delivery_type === 'delivery' ? 'required|string' : 'nullable',
            'delivery_type'     => 'required|in:delivery,pickup',
            'payment_method_id' => 'required|exists:payment_methods,id',
            'notes'             => 'nullable|string',
            'latitude'          => 'nullable|numeric',
            'longitude'         => 'nullable|numeric',
            'wants_invoice'     => 'boolean',
            'document_type'     => 'required_if:wants_invoice,true|in:ci,ruc',
            'document'          => 'required_if:wants_invoice,true|string|max:20',
            'company_name'      => 'nullable|string|max:255',
        ];
    }

    protected function messages(): array
    {
        return [
            'customer_name.required'     => 'El nombre es obligatorio.',
            'customer_phone.required'    => 'El teléfono es obligatorio.',
            'customer_address.required'  => 'La dirección es obligatoria para delivery.',
            'payment_method_id.required' => 'Seleccioná un método de pago.',
            'payment_method_id.exists'   => 'Método de pago inválido.',
            'document.required_if'       => 'Ingresá tu número de documento para la factura.',
            'document_type.required_if'  => 'Seleccioná el tipo de documento.',
        ];
    }

    private function calcItemTotal($item): float
    {
        $extras = collect($item->customizations ?? [])->sum('price');
        return ($item->variant->price + $extras) * $item->quantity;
    }

    public function placeOrder(): void
    {
        $this->validate();

        $cartItems = auth()->user()
            ->cartItems()
            ->with(['product', 'variant.cupSize'])
            ->get();

        if ($cartItems->isEmpty()) {
            session()->flash('error', 'Tu carrito está vacío.');
            $this->redirect(route('cart'));
            return;
        }

        // Verificación rápida pre-transacción (UX — evita abrir DB si es obvio)
        foreach ($cartItems as $item) {
            if (!$item->variant->hasStock($item->quantity)) {
                session()->flash('error',
                    "Stock insuficiente para {$item->product->name} ({$item->variant->volume}ml). Revisá tu carrito."
                );
                $this->redirect(route('cart'));
                return;
            }
        }

        $subtotal = $cartItems->sum(fn($item) => $this->calcItemTotal($item));
        $total    = $subtotal;

        try {
            
            $selectedMethod = PaymentMethod::find($this->payment_method_id);

            if ($selectedMethod && !$selectedMethod->isAvailableFor($this->delivery_type)) {
                $this->addError('payment_method_id', 'El método de pago no está disponible para este tipo de entrega.');
                return;
            }

            DB::beginTransaction();

            // Número de pedido secuencial (sin colisiones)
            $date        = date('Ymd');
            $todayCount  = \App\Models\Order::whereDate('created_at', today())
                ->where('order_number', 'like', "WEB-{$date}%")
                ->lockForUpdate()
                ->count() + 1;
            $orderNumber = 'WEB-' . $date . '-' . str_pad($todayCount, 4, '0', STR_PAD_LEFT);

            $order = Order::create([
                'order_number'      => $orderNumber,
                'user_id'           => auth()->id(),
                'delivery_zone_id'  => null,
                'payment_method_id' => $this->payment_method_id,
                'delivery_type'     => $this->delivery_type,
                'customer_name'     => mb_strtoupper($this->customer_name),
                'customer_phone'    => $this->customer_phone,
                'customer_address'  => $this->customer_address ?: null,
                'customer_city'     => 'Ciudad del Este',
                'latitude'          => $this->latitude ?: null,
                'longitude'         => $this->longitude ?: null,
                'subtotal'          => $subtotal,
                'delivery_cost'     => 0,
                'total'             => $total,
                'status'            => 'pending',
                'payment_status'    => 'pending',
                'source'            => 'web',
                'notes'             => $this->notes ?: null,
            ]);

            foreach ($cartItems as $item) {
                $customizations      = $item->customizations ?? [];
                $extrasUnit          = collect($customizations)->sum('price');
                $itemSubtotal        = ($item->variant->price + $extrasUnit) * $item->quantity;
                $customizationsExtra = $extrasUnit * $item->quantity;

                // ✅ lockForUpdate — bloquea la fila hasta que termine el commit
                // Esto garantiza que dos requests simultáneos no lean el mismo stock
                $variant = \App\Models\ProductVariant::with('cupSize')
                    ->lockForUpdate()
                    ->findOrFail($item->variant->id);

                // Verificación REAL dentro de la transacción con datos frescos y bloqueados
                if (!$variant->hasStock($item->quantity)) {
                    throw new \Exception(
                        "Stock insuficiente para {$item->product->name} ({$variant->volume}ml). " .
                        "Otro cliente acaba de comprar el último stock."
                    );
                }

                $orderItem = OrderItem::create([
                    'order_id'                => $order->id,
                    'product_id'              => $item->product_id,
                    'product_variant_id'      => $variant->id,
                    'product_name'            => $item->product->name,
                    'volume'                  => $variant->volume,
                    'price'                   => $variant->price,
                    'quantity'                => $item->quantity,
                    'subtotal'                => $itemSubtotal,
                    'customizations_subtotal' => $customizationsExtra,
                    'price_channel'           => 'web',
                ]);

                foreach ($customizations as $c) {
                    if (class_exists(OrderItemCustomization::class)) {
                        OrderItemCustomization::create([
                            'order_item_id'           => $orderItem->id,
                            'customization_option_id' => $c['option_id'] ?? null,
                            'quantity'                => $item->quantity,
                            'price'                   => $c['price'],
                            'option_name'             => $c['name'],
                        ]);
                    }
                }

                $item->variant->decrementStock($item->quantity);
            }

            auth()->user()->cartItems()->delete();

            // Guardar datos de facturación en el perfil para futuras compras
            if ($this->wants_invoice && $this->document) {
                auth()->user()->update([
                    'document'      => $this->document,
                    'document_type' => $this->document_type,
                    'company_name'  => $this->document_type === 'ruc' ? $this->company_name : null,
                ]);
            }

            DB::commit();

        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('Error placeOrder: ' . $e->getMessage());

            // Si es error de stock, mostrar mensaje específico y redirigir al carrito
            // para que el usuario vea qué cambió
            $isStockError = str_contains($e->getMessage(), 'Stock insuficiente');
            session()->flash('error', $e->getMessage());

            if ($isStockError) {
                $this->redirect(route('cart'));
            }
            return;
        }

        $whatsappUrl = $this->buildWhatsAppUrl($order, $cartItems);
        $this->dispatch('openWhatsAppNow', url: $whatsappUrl);
        session()->flash('order_created', $order->id);
    }

    private function buildWhatsAppUrl(Order $order, $cartItems): string
    {
        $pm = PaymentMethod::find($this->payment_method_id);

        $msg  = "*NUEVO PEDIDO - Taskinho Açaí*\n";
        $msg .= "================================\n\n";
        $msg .= "*PEDIDO:* {$order->order_number}\n";
        $msg .= "*Fecha:* " . $order->created_at->format('d/m/Y H:i') . "\n\n";

        $msg .= "*CLIENTE*\n";
        $msg .= "Nombre: *{$order->customer_name}*\n";
        $msg .= "Tel: {$order->customer_phone}\n\n";

        if ($this->delivery_type === 'delivery') {
            $msg .= "*ENTREGA: DELIVERY*\n";
            $msg .= "Dirección: {$order->customer_address}\n";
            $msg .= "_Costo de envío a confirmar_\n\n";
        } else {
            $msg .= "*ENTREGA: RETIRO EN TIENDA*\n\n";
        }

        $msg .= "*PRODUCTOS*\n";
        foreach ($cartItems as $item) {
            $customizations = $item->customizations ?? [];
            $extrasUnit     = collect($customizations)->sum('price');
            $itemTotal      = ($item->variant->price + $extrasUnit) * $item->quantity;

            $msg .= "• {$item->product->name} {$item->variant->volume}ml × {$item->quantity}";
            $msg .= " = " . number_format($itemTotal, 0, ',', '.') . " Gs\n";

            if (!empty($customizations)) {
                $msg .= "  _Base: " . number_format($item->variant->price, 0, ',', '.') . " Gs_\n";
                foreach ($customizations as $c) {
                    $precioTexto = $c['price'] > 0
                        ? '+' . number_format($c['price'], 0, ',', '.') . ' Gs'
                        : 'incluido';
                    $msg .= "  _+ {$c['name']}: {$precioTexto}_\n";
                }
            }
        }

        $msg .= "\n*Subtotal:* " . number_format($order->subtotal, 0, ',', '.') . " Gs\n";

        if ($this->delivery_type === 'delivery') {
            $msg .= "*Total parcial:* " . number_format($order->total, 0, ',', '.') . " Gs _(+ delivery)_\n\n";
        } else {
            $msg .= "*TOTAL:* " . number_format($order->total, 0, ',', '.') . " Gs\n\n";
        }

        $msg .= "*PAGO:* {$pm->name}\n";

        if ($pm->bank_details) {
            $msg .= "Banco: {$pm->bank_details['bank']}\n";
            $msg .= "Cuenta: {$pm->bank_details['account_number']}\n";
            $msg .= "Titular: {$pm->bank_details['account_holder']}\n";
        }

        if ($pm->instructions) {
            $msg .= "\n_{$pm->instructions}_\n";
        }

        // Factura
        if ($this->wants_invoice && $this->document) {
            $msg .= "\n*FACTURA REQUERIDA* 🧾\n";
            $tipoDoc = $this->document_type === 'ruc' ? 'RUC' : 'CI';
            $msg .= "{$tipoDoc}: {$this->document}\n";
            if ($this->document_type === 'ruc' && $this->company_name) {
                $msg .= "Razón Social: {$this->company_name}\n";
            }
        }

        if ($order->notes) {
            $msg .= "\n*Notas:* {$order->notes}\n";
        }

        $msg .= "\n_Por favor confirmar recepción_ 🙏";

        return 'https://wa.me/' . self::COMPANY_WHATSAPP . '?text=' . urlencode($msg);
    }

    public function render()
    {
        $cartItems = auth()->user()
            ->cartItems()
            ->with(['product', 'variant.cupSize'])
            ->get();

        $subtotal = $cartItems->sum(fn($item) => $this->calcItemTotal($item));

        $paymentMethods = PaymentMethod::where('is_active', true)
        ->availableFor($this->delivery_type)
        ->get();

        return view('livewire.customer.checkout', [
            'cartItems'      => $cartItems,
            'subtotal'       => $subtotal,
            'paymentMethods' => $paymentMethods,
            'deliveryCost'   => 0,
            'total'          => $subtotal,
        ])->layout('components.layouts.app');
    }

     /**
     * Cuando cambia el tipo de entrega, resetear el método de pago
     * si el seleccionado no es válido para el nuevo tipo.
     */
    public function updatedDeliveryType(string $value): void
    {
        if (!$this->payment_method_id) return;

        $method = \App\Models\PaymentMethod::find($this->payment_method_id);

        if ($method && !$method->isAvailableFor($value)) {
            $this->payment_method_id = '';
        }
    }
}
